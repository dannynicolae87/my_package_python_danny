# Unique generate_password
A simple packet for generate unique and safety passwords

## Instalation

```bash
pip install unique_code_generator